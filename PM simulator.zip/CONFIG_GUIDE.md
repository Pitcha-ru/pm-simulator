# ⚙️ Руководство по настройке баланса игры

Все параметры игры можно редактировать через `config.json` без повторного деплоя.

## 🎯 Основные параметры

### Жизни

```json
"lives": {
    "startLives": 3,      // Жизней в начале игры
    "maxLives": 3         // Максимум жизней
}
```

**Что изменить:**
- Увеличить `startLives` до 5 → игра станет легче
- Уменьшить до 1 → hardcore режим

### Уровни

```json
"levels": {
    "maxLevels": 30       // Всего уровней в игре
}
```

### Департаменты

```json
"departments": {
    "startActive": 4,           // Департаментов в начале
    "growth": {
        "mode": "linearStep",   // Режим роста
        "addCount": 1,          // Добавлять по X департаментов
        "everyLevels": 2        // Каждые X уровней
    }
}
```

**Пример:** Каждые 2 уровня добавляется 1 новый департамент
- Уровень 1: 4 департамента
- Уровень 3: 5 департаментов
- Уровень 5: 6 департаментов

**Сделать сложнее:**
```json
"addCount": 2,        // Добавлять сразу по 2
"everyLevels": 1      // Каждый уровень
```

## ⏱️ Таймеры задач

### Время на выполнение задачи

```json
"timers": {
    "regular": {
        "baseSeconds": 18,              // Базовое время (сек)
        "perLevelScaling": {
            "mode": "constant",         // Режим: constant = не меняется
            "keepConstant": true
        }
    }
}
```

**Сделать сложнее (уменьшить время):**
```json
"baseSeconds": 12     // Меньше времени на задачу
```

**Сделать проще:**
```json
"baseSeconds": 25     // Больше времени
```

### Множители времени по приоритетам

```json
"priorityTimeMultipliers": {
    "regular": 1.0,     // 100% времени
    "serious": 0.85,    // 85% времени
    "critical": 0.70    // 70% времени
}
```

**Пример:** Critical задача с base=18s → 18 × 0.70 = 12.6 секунд

### Интервал появления новых карточек

```json
"spawnInterval": {
    "baseSeconds": 6,               // Интервал на 1 уровне
    "perLevelScaling": {
        "mode": "exponential",
        "multiplierEachLevel": 0.92,  // Каждый уровень × 0.92
        "minSeconds": 2               // Минимальный интервал
    }
}
```

**Формула:** `interval = max(minSeconds, baseSeconds × (0.92 ^ (level - 1)))`

**Примеры по уровням:**
- Уровень 1: 6.00 сек
- Уровень 5: 4.68 сек
- Уровень 10: 3.27 сек
- Уровень 20: 1.43 сек (но ограничено minSeconds=2)

**Сделать сложнее (карточки появляются чаще):**
```json
"multiplierEachLevel": 0.88,  // Быстрее уменьшается
"minSeconds": 1.5             // Можно еще быстрее
```

**Сделать проще:**
```json
"multiplierEachLevel": 0.95,  // Медленнее уменьшается
"minSeconds": 3               // Не быстрее 3 сек
```

## 💯 Очки и скоринг

### Базовые очки

```json
"scoring": {
    "basePoints": 100      // Базовые очки за задачу
}
```

### Множители по приоритетам

```json
"priorityScoreMultipliers": {
    "regular": 1.0,        // 100 очков
    "serious": 1.35,       // 135 очков
    "critical": 1.90       // 190 очков
}
```

**Пример:** Сделать Critical еще выгоднее:
```json
"critical": 2.5    // 250 очков за критическую задачу
```

### Бонус за скорость

```json
"timeBonus": {
    "enabled": true,
    "mode": "linear",
    "maxBonus": 60,                       // Максимальный бонус
    "bonusIfFinishedInFirstPercent": 0.25, // Первые 25% времени
    "bonusFallsToZeroAtPercent": 1.0      // К концу времени = 0
}
```

**Как работает:**
- Выполнил за первые 25% времени → +60 очков
- Выполнил за 50% времени → +30 очков
- Выполнил за 100% времени → 0 очков

**Увеличить бонус:**
```json
"maxBonus": 100,
"bonusIfFinishedInFirstPercent": 0.33  // Первые 33% дают макс.бонус
```

### Streak (серия успехов)

```json
"streak": {
    "enabled": true,
    "maxMultiplier": 1.5,      // Максимальный множитель
    "gainPerSuccess": 0.05,    // +5% за каждый успех
    "resetOnFail": true        // Сброс при ошибке
}
```

**Как работает:**
- 1 успех: ×1.05
- 5 успехов: ×1.25
- 10 успехов: ×1.50 (макс.)

**Сделать streak мощнее:**
```json
"maxMultiplier": 2.0,
"gainPerSuccess": 0.10     // +10% за успех
```

## 🎲 Шансы приоритетов

```json
"taskSpawn": {
    "priorityChances": {
        "mode": "curves",
        "seriousCurve": {
            "startAtLevel": 1,
            "endAtLevel": 20,
            "startValue": 0.15,
            "endValue": 0.35,
            "exponent": 2
        },
        "criticalCurve": {
            "startAtLevel": 5,
            "endAtLevel": 25,
            "startValue": 0.05,
            "endValue": 0.25,
            "exponent": 2.5
        }
    }
}
```

**Как работает:**
- `regular` = 1 - serious - critical (автоматически)
- Кривые плавно изменяют шансы с повышением уровня

**Примеры:**
- Уровень 1: Regular 80%, Serious 15%, Critical 5%
- Уровень 10: Regular 60%, Serious 25%, Critical 15%
- Уровень 20+: Regular 40%, Serious 35%, Critical 25%

**Больше сложных задач:**
```json
"seriousCurve": {
    "endValue": 0.40     // До 40% serious
},
"criticalCurve": {
    "startAtLevel": 3,   // Critical появляется раньше
    "endValue": 0.30     // До 30% critical
}
```

## 🃏 Одновременные карточки

```json
"multiCard": {
    "enabled": true,
    "maxSimultaneousCards": 3    // Макс. карточек на экране
}
```

**Усложнить:**
```json
"maxSimultaneousCards": 5    // Больше карточек = сложнее
```

**Упростить (классический режим):**
```json
"maxSimultaneousCards": 1    // Только одна карточка
```

## 📊 Примеры конфигов

### Легкий режим (для новичков)

```json
{
  "lives": { "startLives": 5 },
  "timers": {
    "regular": { "baseSeconds": 25 }
  },
  "spawnInterval": {
    "baseSeconds": 8,
    "perLevelScaling": { "multiplierEachLevel": 0.95 }
  },
  "scoring": {
    "timeBonus": { "maxBonus": 100 }
  }
}
```

### Hardcore режим

```json
{
  "lives": { "startLives": 1 },
  "timers": {
    "regular": { "baseSeconds": 12 }
  },
  "spawnInterval": {
    "baseSeconds": 4,
    "perLevelScaling": { "multiplierEachLevel": 0.88, "minSeconds": 1 }
  },
  "multiCard": { "maxSimultaneousCards": 5 }
}
```

### Zen режим (расслабленный)

```json
{
  "lives": { "startLives": 10 },
  "timers": {
    "regular": { "baseSeconds": 30 }
  },
  "spawnInterval": {
    "baseSeconds": 10,
    "perLevelScaling": { "mode": "constant", "keepConstant": true }
  },
  "multiCard": { "maxSimultaneousCards": 1 }
}
```

## 🔄 Как применить изменения

1. Отредактируйте `config.json` в Supabase Storage
2. Сохраните файл
3. Игроки получат изменения при перезагрузке страницы (Ctrl+F5)

**Тестирование локально:**
1. Измените `config.json` в проекте
2. Запустите `npm run dev`
3. Протестируйте изменения
4. Загрузите в Supabase

## ⚠️ Важные ограничения

### Минимальные значения

```json
"validation": {
    "minSecondsFloor": 1,           // Таймер не меньше 1 сек
    "clampDepartmentsActive": true  // Ограничить по макс.
}
```

### Математические ограничения

- Все таймеры >= 1 секунда
- Множители > 0
- Шансы приоритетов в сумме = 1.0
- Количество департаментов <= доступно в `departments.json`

## 🧪 Советы по балансу

1. **Тестируйте на себе** - проиграйте 5-10 игр после изменений
2. **Меняйте по одному параметру** за раз
3. **Смотрите на статистику** - на каком уровне игроки проигрывают?
4. **Прогрессия сложности** должна быть плавной
5. **Первые уровни** должны быть легкими (обучение)
6. **Последние уровни** должны быть вызовом

## 📈 Рекомендуемая прогрессия

- **Уровни 1-5:** Легко, 4-5 департаментов, в основном regular задачи
- **Уровни 6-15:** Средне, добавляются департаменты, больше serious
- **Уровни 16-25:** Сложно, 8-10 департаментов, много critical
- **Уровни 26-30:** Очень сложно, максимум департаментов и скорости

---

**Удачи в настройке баланса! 🎮**

_Если создадите интересную конфигурацию - поделитесь с сообществом!_

